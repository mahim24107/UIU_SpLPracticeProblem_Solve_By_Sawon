#include<stdio.h>
int main(){
int i,j,n,v;
printf("Enter term:");
scanf("%d",&n);
v=n;
for(i=1;i<=n;i++){

    for(j=v;j>=1;j--){
        printf("*");
}
     v--;
    printf("\n");
}















return 0;
}

#include<stdio.h>
int main(){
int n,i,j,v;
printf("Enter N:");
scanf("%d",&n);

for(i=1;i<=n;i++){



    for(j=1;j<=n;j++){

     if(j==1||j==n||i== ceil(n/2 + 0.5))
        printf("H");
     else
        printf(" ");

    }
    printf("\n");
}


return 0;
}


#include <stdio.h>

int main() {
    int X, guess, N;

    printf("Player-1, enter the number X: ");
    scanf("%d", &X);

    printf("Player-1, enter the maximum number of tries (N): ");
    scanf("%d", &N);

    for (int i = 1; i <= N; ++i) {
        printf("Player-2, make a guess: ");
        scanf("%d", &guess);

        if (guess == X) {
            printf("Right, Player-2 wins!\n");
            break;  
        } else {
            printf("Wrong, %d Choice(s) Left!\n", N - i);

            if (i == N) {
                printf("Player-1 wins!\n");
            }
        }
    }

    return 0;
}

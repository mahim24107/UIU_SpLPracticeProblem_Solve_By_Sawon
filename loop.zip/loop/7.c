#include <stdio.h>

int main() {
    char input;



    while (1) {
            printf("Enter characters:");
        scanf(" %c", &input);

        if (input == 'A') {
            printf("You typed 'A'. Exiting the program.\n");
            break;
        }

        printf("Input: %c\n", input);
    }

    return 0;
}

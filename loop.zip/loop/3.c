#include <stdio.h>

int main() {
    int N;

    printf("Enter the value of N: ");
    scanf("%d", &N);

    for (int i = 1; i <= N; ++i) {
        printf("%d", i % 2);

        if (i < N) {
            printf(", ");
        }
    }

    return 0;
}


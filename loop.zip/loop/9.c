#include<stdio.h>
int main(){

    int amstu,i;
    float a,hw,ct,mt,tf,sum;
    printf("Enter the amount of student:");
    scanf("%d",&amstu);
    for(i=1;i<=amstu;i++){
            printf("attendance:");
            scanf("%f",&a);
            printf("Hw:");
            scanf("%f",&hw);
            printf("Ct:");
            scanf("%f",&ct);
            printf("Mt:");
            scanf("%f",&mt);
            printf("Tf:");
            scanf("%f",&tf);
            mt= (30*mt)/50;
            tf= (40*tf)/100;
            sum= (tf+mt+a+hw+ct) ;

            printf("student %d :",i);
            if(sum>=90&&sum<=100){
                printf("A\n");
            }else if(sum>=86&&sum<=89){
                printf("A-\n");
            }else if(sum>=82&&sum<=85){
                printf("B+\n");
    }else if(sum>=78&&sum<=81){
                printf("B\n");
    }else if(sum>=74&&sum<=77){
                printf("B-\n");
    }else if(sum>=70&&sum<=73){
                printf("C+\n");
    }else if(sum>=66&&sum<=69){
                printf("C\n");
    }else if(sum>=62&&sum<=65){
                printf("C-\n");
    }else if(sum>=58&&sum<=61){
                printf("D+\n");
    }else if(sum>=55&&sum<=57){
                printf("D\n");
    }else if(sum<55&&sum>=0){
                printf("F\n");
    }


    }
















return 0;
}

#include <stdio.h>



int main() {
    int x, y,p=1;

    printf("Enter the value of x: ");
    scanf("%d", &x);

    printf("Enter the value of y: ");
    scanf("%d", &y);

    for(int i=1;i<=y;i++){
        p=p*x;
    }
    printf("%d",p);

    return 0;
}

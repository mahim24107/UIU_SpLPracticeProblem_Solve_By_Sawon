#include <stdio.h>

int main() {
    int N;
    double number, sum = 0;

    printf("Enter the value of N: ");
    scanf("%d", &N);

    if (N <= 0) {
        printf("Please enter a valid positive value for N.\n");
        scanf("%d", &N);
    }

    printf("Enter %d numbers:\n", N);
    for (int i = 1; i <= N; ++i) {
        printf("Enter number %d: ", i);
        scanf("%lf", &number);
        sum += number;
    }

    double average = sum / N;
    printf("The average of %d numbers is: %.2lf\n", N, average);

    return 0;
}

#include <stdio.h>


int main() {
    int N,i,p=1;

    printf("Enter a number N: ");
    scanf("%d", &N);
    for(i=1;i<=N;i++){
        p=p*i;
    }
printf("Factorial:%d",p);

    return 0;
}


#include <stdio.h>
int main() {
   int N,R,i,p=1,m=1,n=1;

    printf("Enter a number N: ");
    scanf("%d", &N);
    printf("Enter value of R: ");
    scanf("%d", &R);
    for(i=1;i<=N;i++){
        p=p*i;
    }
    for(i=1;i<=R;i++){
        m=m*i;
    }
    for(i=1;i<=N-R;i++){
        n=n*i;
    }

printf("%d",p/(m*n));

    return 0;
}

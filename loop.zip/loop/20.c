#include <stdio.h>

int main() {
    int n, i;
    long sum = 0, term = 0;

    printf("Enter the number of terms (n): ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        term = term * 10 + i;
        sum += term;
    }

    printf(" %ld\n", n, sum);

    return 0;
}

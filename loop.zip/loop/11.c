#include <stdio.h>

int main() {
    int n;
    double result = 0;


    printf("Enter the number of terms (N): ");
    scanf("%d", &n);


    for (int i = 1; i <= n; i++) {
        result += (i * i) * (i+1);
    }


    printf("Result of the series for the first %d terms: %.2lf\n", n, result);

    return 0;
}

#include <stdio.h>

int main() {
    double x, term, sum;
    int i, n = 10;

    printf("Enter the value of x: ");
    scanf("%lf", &x);

    term = x;
    sum = x;

    for(i = 3; i <= 15; i += 2) {
        term = -term * x * x / (i * (i-1));
        sum += term;
    }

    printf("Sin(%.2lf) = %.3lf\n", x, sum);

    return 0;
}

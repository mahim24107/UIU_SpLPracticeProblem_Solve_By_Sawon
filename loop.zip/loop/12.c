#include <stdio.h>

int main() {
    int N;

    printf("Enter the value of N: ");
    scanf("%d", &N);

    int firstTerm = 1, secondTerm = 1;

    printf("Fibonacci series up to %d terms:\n", N);
    printf("%d, %d", firstTerm, secondTerm);

    for (int i = 3; i <= N; ++i) {
        int nextTerm = firstTerm + secondTerm;

        printf(", %d", nextTerm);

        firstTerm = secondTerm;
        secondTerm = nextTerm;
    }

    printf("\n");

    return 0;
}

#include <stdio.h>

int main() {
    int X, Y;

    printf("Enter the value of X: ");
    scanf("%d", &X);

    printf("Enter the value of Y: ");
    scanf("%d", &Y);

    while (X != Y) {
        printf("%d", X, X * X);

        if (X < Y) {
            X++;
            printf(",");
        } else {
            X--;
            printf(",");
        }
    }

    printf("Reached!\n");

    return 0;
}
